-- Step 1: Create the TravelDestinationsDB Database
CREATE DATABASE TravelDestinationsDB;
GO

-- Step 2: Use the TravelDestinationsDB Database
USE TravelDestinationsDB;
GO

-- Step 3: Create the Destinations Table
CREATE TABLE Destinations (
    DestinationID INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(100) NOT NULL,
    Country NVARCHAR(50),
    Type NVARCHAR(50),
    Description NVARCHAR(MAX)
);
GO

-- Step 4: Insert Sample Data (Optional)
-- Example: Inserting sample destination data
INSERT INTO Destinations (Name, Country, Type, Description)
VALUES 
('Eiffel Tower', 'France', 'Landmark', 'Iconic Parisian landmark with stunning views.'),
('Great Wall of China', 'China', 'Historical', 'Ancient wall stretching across northern China.');
GO

-- Step 5: Query the Table to Verify Data (Optional)
-- Example: Select all destinations
SELECT * FROM Destinations;
GO
