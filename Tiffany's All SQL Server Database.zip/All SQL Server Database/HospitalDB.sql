-- Step 1: Create the HospitalDB Database
CREATE DATABASE HospitalDB;
GO

-- Step 2: Use the HospitalDB Database
USE HospitalDB;
GO

-- Step 3: Create the Patients Table
CREATE TABLE Patients (
    PatientID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    DateOfBirth DATE,
    Address NVARCHAR(255),
    PhoneNumber NVARCHAR(20),
    Email NVARCHAR(100)
);
GO

-- Step 4: Create the Doctors Table
CREATE TABLE Doctors (
    DoctorID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    Specialty NVARCHAR(100),
    PhoneNumber NVARCHAR(20),
    Email NVARCHAR(100)
);
GO

-- Step 5: Create the Appointments Table
CREATE TABLE Appointments (
    AppointmentID INT PRIMARY KEY IDENTITY(1,1),
    PatientID INT,
    DoctorID INT,
    AppointmentDate DATE,
    Reason NVARCHAR(255),
    FOREIGN KEY (PatientID) REFERENCES Patients(PatientID),
    FOREIGN KEY (DoctorID) REFERENCES Doctors(DoctorID)
);
GO

-- Step 6: Create the Treatments Table
CREATE TABLE Treatments (
    TreatmentID INT PRIMARY KEY IDENTITY(1,1),
    PatientID INT,
    DoctorID INT,
    TreatmentDate DATE,
    TreatmentDescription NVARCHAR(255),
    Outcome NVARCHAR(255),
    FOREIGN KEY (PatientID) REFERENCES Patients(PatientID),
    FOREIGN KEY (DoctorID) REFERENCES Doctors(DoctorID)
);
GO

-- Step 7: Create the Staff Table
CREATE TABLE Staff (
    StaffID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    Role NVARCHAR(50),
    PhoneNumber NVARCHAR(20),
    Email NVARCHAR(100)
);
GO

-- Step 8: Insert Sample Data (Optional)
-- Example: Inserting sample patient data
INSERT INTO Patients (FirstName, LastName, DateOfBirth, Address, PhoneNumber, Email)
VALUES 
('John', 'Doe', '1980-05-15', '123 Elm Street', '555-1234', 'john.doe@example.com'),
('Jane', 'Smith', '1992-08-22', '456 Oak Avenue', '555-5678', 'jane.smith@example.com');
GO

-- Example: Inserting sample doctor data
INSERT INTO Doctors (FirstName, LastName, Specialty, PhoneNumber, Email)
VALUES 
('Emily', 'Johnson', 'Cardiology', '555-8765', 'emily.johnson@example.com'),
('Michael', 'Brown', 'Orthopedics', '555-4321', 'michael.brown@example.com');
GO

-- Example: Inserting sample staff data
INSERT INTO Staff (FirstName, LastName, Role, PhoneNumber, Email)
VALUES 
('Alice', 'Williams', 'Nurse', '555-6789', 'alice.williams@example.com'),
('David', 'Miller', 'Receptionist', '555-9876', 'david.miller@example.com');
GO

-- Example: Inserting sample appointment data
INSERT INTO Appointments (PatientID, DoctorID, AppointmentDate, Reason)
VALUES 
(1, 1, '2024-10-01', 'Routine check-up'),
(2, 2, '2024-10-02', 'Fracture follow-up');
GO

-- Example: Inserting sample treatment data
INSERT INTO Treatments (PatientID, DoctorID, TreatmentDate, TreatmentDescription, Outcome)
VALUES 
(1, 1, '2024-10-01', 'Blood pressure management', 'Stable'),
(2, 2, '2024-10-02', 'Cast removal', 'Recovered');
GO

-- Step 9: Query the Tables to Verify Data (Optional)
-- Example: Select all patients
SELECT * FROM Patients;
GO

-- Example: Select all doctors
SELECT * FROM Doctors;
GO

-- Example: Select all staff
SELECT * FROM Staff;
GO

-- Example: Select all appointments
SELECT * FROM Appointments;
GO

-- Example: Select all treatments
SELECT * FROM Treatments;
GO
