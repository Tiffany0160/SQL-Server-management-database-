-- Step 1: Create the StudentsDB Database
CREATE DATABASE StudentsDB;
GO

-- Step 2: Use the StudentsDB Database
USE StudentsDB;
GO

-- Step 3: Create the Students Table
CREATE TABLE Students (
    StudentID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    DateOfBirth DATE,
    EnrollmentDate DATE
);
GO

-- Step 4: Insert Sample Data (Optional)
-- Example: Inserting sample student data
INSERT INTO Students (FirstName, LastName, DateOfBirth, EnrollmentDate)
VALUES 
('Emily', 'Davis', '2004-08-15', '2022-09-01'),
('Michael', 'Brown', '2003-11-22', '2022-09-01');
GO

-- Step 5: Query the Table to Verify Data (Optional)
-- Example: Select all students
SELECT * FROM Students;
GO
