-- Step 1: Create the RecipesDB Database
CREATE DATABASE RecipesDB;
GO

-- Step 2: Use the RecipesDB Database
USE RecipesDB;
GO

-- Step 3: Create the Recipes Table
CREATE TABLE Recipes (
    RecipeID INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(100) NOT NULL,
    Cuisine NVARCHAR(50),
    Ingredients NVARCHAR(MAX),
    Instructions NVARCHAR(MAX)
);
GO

-- Step 4: Insert Sample Data (Optional)
-- Example: Inserting sample recipe data
INSERT INTO Recipes (Name, Cuisine, Ingredients, Instructions)
VALUES 
('Spaghetti Carbonara', 'Italian', 'Spaghetti, eggs, pancetta, Parmesan cheese', 'Cook pasta. Mix eggs and cheese. Combine with pancetta.'),
('Chicken Curry', 'Indian', 'Chicken, curry powder, onions, garlic', 'Cook chicken. Add curry powder and other ingredients. Simmer.');
GO

-- Step 5: Query the Table to Verify Data (Optional)
-- Example: Select all recipes
SELECT * FROM Recipes;
GO
