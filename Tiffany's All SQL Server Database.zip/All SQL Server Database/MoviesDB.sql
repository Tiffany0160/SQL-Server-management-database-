-- Step 1: Create the MoviesDB Database
CREATE DATABASE MoviesDB;
GO

-- Step 2: Use the MoviesDB Database
USE MoviesDB;
GO

-- Step 3: Create the Movies Table
CREATE TABLE Movies (
    MovieID INT PRIMARY KEY IDENTITY(1,1),
    Title NVARCHAR(100) NOT NULL,
    Director NVARCHAR(100),
    Genre NVARCHAR(50),
    ReleaseDate DATE
);
GO

-- Step 4: Insert Sample Data (Optional)
-- Example: Inserting sample movie data
INSERT INTO Movies (Title, Director, Genre, ReleaseDate)
VALUES 
('Inception', 'Christopher Nolan', 'Sci-Fi', '2010-07-16'),
('The Godfather', 'Francis Ford Coppola', 'Crime', '1972-03-24');
GO

-- Step 5: Query the Table to Verify Data (Optional)
-- Example: Select all movies
SELECT * FROM Movies;
GO
