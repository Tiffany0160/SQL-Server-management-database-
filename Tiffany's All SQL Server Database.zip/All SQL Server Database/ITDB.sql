-- Step 1: Create the ITDB Database
CREATE DATABASE ITDB;
GO

-- Step 2: Use the ITDB Database
USE ITDB;
GO

-- Step 3: Create the Users Table
CREATE TABLE Users (
    UserID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    Email NVARCHAR(100),
    Phone NVARCHAR(20),
    Department NVARCHAR(100),
    Position NVARCHAR(100)
);
GO

-- Step 4: Create the Assets Table
CREATE TABLE Assets (
    AssetID INT PRIMARY KEY IDENTITY(1,1),
    AssetName NVARCHAR(100) NOT NULL,
    AssetType NVARCHAR(50),
    PurchaseDate DATE,
    PurchaseCost DECIMAL(10, 2),
    AssignedTo INT,
    FOREIGN KEY (AssignedTo) REFERENCES Users(UserID)
);
GO

-- Step 5: Create the Tickets Table
CREATE TABLE Tickets (
    TicketID INT PRIMARY KEY IDENTITY(1,1),
    Title NVARCHAR(255) NOT NULL,
    Description NVARCHAR(1000),
    Status NVARCHAR(50),
    Priority NVARCHAR(50),
    ReportedBy INT,
    AssignedTo INT,
    CreatedDate DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (ReportedBy) REFERENCES Users(UserID),
    FOREIGN KEY (AssignedTo) REFERENCES Users(UserID)
);
GO

-- Step 6: Create the Software Table
CREATE TABLE Software (
    SoftwareID INT PRIMARY KEY IDENTITY(1,1),
    SoftwareName NVARCHAR(100) NOT NULL,
    Version NVARCHAR(50),
    LicenseKey NVARCHAR(100),
    InstallDate DATE,
    InstalledOn INT,
    FOREIGN KEY (InstalledOn) REFERENCES Assets(AssetID)
);
GO

-- Step 7: Insert Sample Data (Optional)
-- Example: Inserting sample user data
INSERT INTO Users (FirstName, LastName, Email, Phone, Department, Position)
VALUES 
('John', 'Doe', 'john.doe@example.com', '123-456-7890', 'IT', 'Systems Administrator'),
('Jane', 'Smith', 'jane.smith@example.com', '987-654-3210', 'Finance', 'Financial Analyst');
GO

-- Example: Inserting sample asset data
INSERT INTO Assets (AssetName, AssetType, PurchaseDate, PurchaseCost, AssignedTo)
VALUES 
('Laptop 1', 'Laptop', '2020-01-15', 1200.00, 1),
('Printer 1', 'Printer', '2021-05-20', 500.00, 2);
GO

-- Example: Inserting sample ticket data
INSERT INTO Tickets (Title, Description, Status, Priority, ReportedBy, AssignedTo, CreatedDate)
VALUES 
('Cannot connect to network', 'User reports inability to access network resources.', 'Open', 'High', 1, 1, '2023-03-10 10:15:00'),
('Software installation issue', 'User requests installation of software XYZ.', 'Open', 'Medium', 2, 1, '2023-03-11 09:30:00');
GO

-- Example: Inserting sample software data
INSERT INTO Software (SoftwareName, Version, LicenseKey, InstallDate, InstalledOn)
VALUES 
('Microsoft Office', '2019', 'ABC123-XYZ456', '2021-02-28', 1),
('Adobe Photoshop', '2022', 'DEF789-GHI101', '2022-04-15', 2);
GO

-- Step 8: Query the Tables to Verify Data (Optional)
-- Example: Select all users
SELECT * FROM Users;
GO

-- Example: Select all assets
SELECT * FROM Assets;
GO

-- Example: Select all tickets
SELECT * FROM Tickets;
GO

-- Example: Select all software installations
SELECT * FROM Software;
GO
