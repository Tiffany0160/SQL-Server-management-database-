-- Step 1: Create the SocialMediaDB Database
CREATE DATABASE SocialMediaDB;
GO

-- Step 2: Use the SocialMediaDB Database
USE SocialMediaDB;
GO

-- Step 3: Create the Users Table
CREATE TABLE Users (
    UserID INT PRIMARY KEY IDENTITY(1,1),
    Username NVARCHAR(50) NOT NULL,
    PasswordHash NVARCHAR(255) NOT NULL,
    Email NVARCHAR(100),
    DateOfBirth DATE
);
GO

-- Step 4: Insert Sample Data (Optional)
-- Example: Inserting sample user data
INSERT INTO Users (Username, PasswordHash, Email, DateOfBirth)
VALUES 
('john_doe', 'hashedpassword123', 'john.doe@example.com', '1990-01-15'),
('jane_smith', 'hashedpassword456', 'jane.smith@example.com', '1992-03-22');
GO

-- Step 5: Query the Table to Verify Data (Optional)
-- Example: Select all users
SELECT * FROM Users;
GO
