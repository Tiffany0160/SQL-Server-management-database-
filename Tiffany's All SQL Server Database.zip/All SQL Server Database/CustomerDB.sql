-- Step 1: Create the CustomersDB Database
CREATE DATABASE CustomersDB;
GO

-- Step 2: Use the CustomersDB Database
USE CustomersDB;
GO

-- Step 3: Create the Customers Table
CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    Email NVARCHAR(100),
    PhoneNumber NVARCHAR(20)
);
GO

-- Step 4: Insert Sample Data (Optional)
-- Example: Inserting sample customer data
INSERT INTO Customers (FirstName, LastName, Email, PhoneNumber)
VALUES 
('Alice', 'Johnson', 'alice.johnson@example.com', '555-1234'),
('Bob', 'Brown', 'bob.brown@example.com', '555-5678');
GO

-- Step 5: Query the Table to Verify Data (Optional)
-- Example: Select all customers
SELECT * FROM Customers;
GO
