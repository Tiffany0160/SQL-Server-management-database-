-- Step 1: Create the DoctorDB Database
CREATE DATABASE DoctorDB;
GO

-- Step 2: Use the DoctorDB Database
USE DoctorDB;
GO

-- Step 3: Create the Doctors Table
CREATE TABLE Doctors (
    DoctorID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    Specialty NVARCHAR(100),
    Phone NVARCHAR(20),
    Email NVARCHAR(100)
);
GO

-- Step 4: Create the Patients Table
CREATE TABLE Patients (
    PatientID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    DateOfBirth DATE,
    Gender NVARCHAR(10),
    Phone NVARCHAR(20),
    Email NVARCHAR(100),
    Address NVARCHAR(255),
    City NVARCHAR(100),
    State NVARCHAR(50),
    PostalCode NVARCHAR(20),
    Country NVARCHAR(50)
);
GO

-- Step 5: Create the Appointments Table
CREATE TABLE Appointments (
    AppointmentID INT PRIMARY KEY IDENTITY(1,1),
    DoctorID INT,
    PatientID INT,
    AppointmentDate DATETIME,
    Reason NVARCHAR(255),
    FOREIGN KEY (DoctorID) REFERENCES Doctors(DoctorID),
    FOREIGN KEY (PatientID) REFERENCES Patients(PatientID)
);
GO

-- Step 6: Create the MedicalRecords Table
CREATE TABLE MedicalRecords (
    RecordID INT PRIMARY KEY IDENTITY(1,1),
    PatientID INT,
    DoctorID INT,
    RecordDate DATE,
    Diagnosis NVARCHAR(255),
    Treatment NVARCHAR(255),
    Notes NVARCHAR(1000),
    FOREIGN KEY (PatientID) REFERENCES Patients(PatientID),
    FOREIGN KEY (DoctorID) REFERENCES Doctors(DoctorID)
);
GO

-- Step 7: Insert Sample Data (Optional)
-- Example: Inserting sample doctor data
INSERT INTO Doctors (FirstName, LastName, Specialty, Phone, Email)
VALUES 
('John', 'Doe', 'Cardiology', '123-456-7890', 'john.doe@example.com'),
('Jane', 'Smith', 'Dermatology', '987-654-3210', 'jane.smith@example.com');
GO

-- Example: Inserting sample patient data
INSERT INTO Patients (FirstName, LastName, DateOfBirth, Gender, Phone, Email, Address, City, State, PostalCode, Country)
VALUES 
('Alice', 'Johnson', '1990-01-01', 'Female', '111-222-3333', 'alice.johnson@example.com', '123 Maple St', 'Anytown', 'CA', '12345', 'USA'),
('Bob', 'Brown', '1985-05-15', 'Male', '444-555-6666', 'bob.brown@example.com', '456 Oak Ave', 'Sometown', 'NY', '54321', 'USA');
GO

-- Example: Inserting sample appointment data
INSERT INTO Appointments (DoctorID, PatientID, AppointmentDate, Reason)
VALUES 
(1, 1, '2023-01-15 10:00:00', 'Regular check-up'),
(2, 2, '2023-01-20 14:30:00', 'Skin rash');
GO

-- Example: Inserting sample medical record data
INSERT INTO MedicalRecords (PatientID, DoctorID, RecordDate, Diagnosis, Treatment, Notes)
VALUES 
(1, 1, '2023-01-15', 'Hypertension', 'Medication', 'Patient advised to reduce salt intake and exercise regularly.'),
(2, 2, '2023-01-20', 'Eczema', 'Topical cream', 'Patient advised to avoid irritants and use moisturizer regularly.');
GO

-- Step 8: Query the Tables to Verify Data (Optional)
-- Example: Select all doctors
SELECT * FROM Doctors;
GO

-- Example: Select all patients
SELECT * FROM Patients;
GO

-- Example: Select all appointments
SELECT * FROM Appointments;
GO

-- Example: Select all medical records
SELECT * FROM MedicalRecords;
GO
