-- Step 1: Create the BusinessDB Database
CREATE DATABASE BusinessDB;
GO

-- Step 2: Use the BusinessDB Database
USE BusinessDB;
GO

-- Step 3: Create the Customers Table
CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    Email NVARCHAR(100),
    Phone NVARCHAR(20),
    Address NVARCHAR(255),
    City NVARCHAR(100),
    State NVARCHAR(50),
    PostalCode NVARCHAR(20),
    Country NVARCHAR(50)
);
GO

-- Step 4: Create the Products Table
CREATE TABLE Products (
    ProductID INT PRIMARY KEY IDENTITY(1,1),
    ProductName NVARCHAR(100) NOT NULL,
    Category NVARCHAR(50),
    Description NVARCHAR(255),
    Price DECIMAL(10, 2)
);
GO

-- Step 5: Create the Orders Table
CREATE TABLE Orders (
    OrderID INT PRIMARY KEY IDENTITY(1,1),
    CustomerID INT,
    OrderDate DATE,
    TotalAmount DECIMAL(10, 2),
    Status NVARCHAR(50),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);
GO

-- Step 6: Create the OrderDetails Table
CREATE TABLE OrderDetails (
    OrderDetailID INT PRIMARY KEY IDENTITY(1,1),
    OrderID INT,
    ProductID INT,
    Quantity INT,
    UnitPrice DECIMAL(10, 2),
    TotalPrice DECIMAL(10, 2),
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
);
GO

-- Step 7: Insert Sample Data (Optional)
-- Example: Inserting sample customer data
INSERT INTO Customers (FirstName, LastName, Email, Phone, Address, City, State, PostalCode, Country)
VALUES 
('John', 'Doe', 'john.doe@example.com', '123-456-7890', '123 Main St', 'Anytown', 'CA', '12345', 'USA'),
('Jane', 'Smith', 'jane.smith@example.com', '987-654-3210', '456 Oak Ave', 'Sometown', 'NY', '54321', 'USA');
GO

-- Example: Inserting sample product data
INSERT INTO Products (ProductName, Category, Description, Price)
VALUES 
('Laptop', 'Electronics', 'High-performance laptop with SSD', 1200.00),
('Printer', 'Office Supplies', 'Color laser printer with wireless capability', 500.00);
GO

-- Example: Inserting sample order data
INSERT INTO Orders (CustomerID, OrderDate, TotalAmount, Status)
VALUES 
(1, '2023-01-15', 1700.00, 'Shipped'),
(2, '2023-01-20', 600.00, 'Processing');
GO

-- Example: Inserting sample order details
-- Note: Ensure OrderID and ProductID values match existing records in Orders and Products tables.
INSERT INTO OrderDetails (OrderID, ProductID, Quantity, UnitPrice, TotalPrice)
VALUES 
(1, 1, 1, 1200.00, 1200.00),
(1, 2, 1, 500.00, 500.00),
(2, 2, 2, 500.00, 1000.00);
GO

-- Step 8: Query the Tables to Verify Data (Optional)
-- Example: Select all customers
SELECT * FROM Customers;
GO

-- Example: Select all products
SELECT * FROM Products;
GO

-- Example: Select all orders
SELECT * FROM Orders;
GO

-- Example: Select all order details
SELECT * FROM OrderDetails;
GO
