-- Step 1: Create the PatientsDB Database
CREATE DATABASE PatientsDB;
GO

-- Step 2: Use the PatientsDB Database
USE PatientsDB;
GO

-- Step 3: Create the Patients Table
CREATE TABLE Patients (
    PatientID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    DateOfBirth DATE,
    Address NVARCHAR(255),
    PhoneNumber NVARCHAR(20)
);
GO

-- Step 4: Insert Sample Data (Optional)
-- Example: Inserting sample patient data
INSERT INTO Patients (FirstName, LastName, DateOfBirth, Address, PhoneNumber)
VALUES 
('John', 'Doe', '1985-05-15', '123 Elm Street', '555-1234'),
('Jane', 'Smith', '1990-07-22', '456 Oak Avenue', '555-5678');
GO

-- Step 5: Query the Table to Verify Data (Optional)
-- Example: Select all patients
SELECT * FROM Patients;
GO
