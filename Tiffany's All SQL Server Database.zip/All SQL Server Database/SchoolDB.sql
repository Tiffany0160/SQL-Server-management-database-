-- Step 1: Create the SchoolDB Database
CREATE DATABASE SchoolDB;
GO

-- Step 2: Use the SchoolDB Database
USE SchoolDB;
GO

-- Step 3: Create the Students Table
CREATE TABLE Students (
    StudentID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    DateOfBirth DATE,
    Gender NVARCHAR(10),
    GradeLevel INT
);
GO

-- Step 4: Create the Teachers Table
CREATE TABLE Teachers (
    TeacherID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    DateOfBirth DATE,
    Gender NVARCHAR(10),
    HireDate DATE,
    Department NVARCHAR(50)
);
GO

-- Step 5: Create the Courses Table
CREATE TABLE Courses (
    CourseID INT PRIMARY KEY IDENTITY(1,1),
    CourseName NVARCHAR(100) NOT NULL,
    CourseCode NVARCHAR(20),
    Description NVARCHAR(255),
    Credits INT
);
GO

-- Step 6: Create the Enrollment Table
CREATE TABLE Enrollment (
    EnrollmentID INT PRIMARY KEY IDENTITY(1,1),
    StudentID INT,
    CourseID INT,
    EnrollmentDate DATE,
    Grade DECIMAL(4, 2),
    FOREIGN KEY (StudentID) REFERENCES Students(StudentID),
    FOREIGN KEY (CourseID) REFERENCES Courses(CourseID)
);
GO

-- Step 7: Insert Sample Data (Optional)
-- Example: Inserting sample student data
INSERT INTO Students (FirstName, LastName, DateOfBirth, Gender, GradeLevel)
VALUES 
('John', 'Doe', '2005-08-15', 'Male', 10),
('Jane', 'Smith', '2006-04-25', 'Female', 9);
GO

-- Example: Inserting sample teacher data
INSERT INTO Teachers (FirstName, LastName, DateOfBirth, Gender, HireDate, Department)
VALUES 
('Michael', 'Johnson', '1980-03-10', 'Male', '2010-08-01', 'Mathematics'),
('Emily', 'Davis', '1985-11-22', 'Female', '2015-02-15', 'Science');
GO

-- Example: Inserting sample course data
INSERT INTO Courses (CourseName, CourseCode, Description, Credits)
VALUES 
('Mathematics I', 'MATH101', 'Introduction to basic mathematics concepts', 3),
('Biology I', 'BIO101', 'Fundamentals of biology and life sciences', 4);
GO

-- Example: Enrolling students in courses
-- Note: Ensure StudentID and CourseID values match existing records in Students and Courses tables.
INSERT INTO Enrollment (StudentID, CourseID, EnrollmentDate, Grade)
VALUES 
(1, 1, '2023-01-15', 85.5),
(2, 2, '2023-01-20', 92.0);
GO

-- Step 8: Query the Tables to Verify Data (Optional)
-- Example: Select all students
SELECT * FROM Students;
GO

-- Example: Select all courses
SELECT * FROM Courses;
GO

-- Example: Select all teachers
SELECT * FROM Teachers;
GO

-- Example: Select all enrollments
SELECT * FROM Enrollment;
GO
