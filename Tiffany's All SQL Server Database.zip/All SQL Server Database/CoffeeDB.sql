-- Step 1: Create the CoffeeDB Database
CREATE DATABASE CoffeeDB;
GO

-- Step 2: Switch to the CoffeeDB Database
USE CoffeeDB;
GO

-- Step 3: Create the Coffee Table with Detailed Columns
CREATE TABLE Coffee (
    CoffeeID INT PRIMARY KEY IDENTITY(1,1),
    CoffeeName NVARCHAR(100) NOT NULL,
    Origin NVARCHAR(100),
    RoastType NVARCHAR(50),
    Price DECIMAL(5, 2) NOT NULL,
    Description NVARCHAR(255),
    StockQuantity INT,
    Supplier NVARCHAR(100),
    DateAdded DATE DEFAULT GETDATE()
);
GO

-- Step 4: Insert Sample Data into the Coffee Table
INSERT INTO Coffee (CoffeeName, Origin, RoastType, Price, Description, StockQuantity, Supplier)
VALUES 
('Ethiopian Yirgacheffe', 'Ethiopia', 'Medium', 12.50, 'Floral and fruity notes with a hint of jasmine', 100, 'Ethiopian Coffee Suppliers'),
('Colombian Supremo', 'Colombia', 'Dark', 10.75, 'Rich and smooth with chocolate undertones', 150, 'Colombian Coffee Exporters'),
('Guatemalan Antigua', 'Guatemala', 'Medium-Dark', 11.00, 'Full-bodied with a smoky aroma and spicy flavor', 200, 'Guatemalan Coffee Traders'),
('Kenyan AA', 'Kenya', 'Light', 13.00, 'Bright acidity with berry and citrus notes', 80, 'Kenyan Coffee Growers'),
('Brazilian Santos', 'Brazil', 'Medium', 9.50, 'Nutty and sweet with a creamy body', 300, 'Brazilian Coffee Farms');
GO

-- Step 5: Query the Coffee Table to Verify the Data
SELECT * FROM Coffee;
GO
