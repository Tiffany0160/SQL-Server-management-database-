-- Step 1: Create the EmployeesDB Database
CREATE DATABASE EmployeesDB;
GO

-- Step 2: Use the EmployeesDB Database
USE EmployeesDB;
GO

-- Step 3: Create the Employees Table
CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    Position NVARCHAR(50),
    Salary DECIMAL(18, 2),
    HireDate DATE
);
GO

-- Step 4: Insert Sample Data (Optional)
-- Example: Inserting sample employee data
INSERT INTO Employees (FirstName, LastName, Position, Salary, HireDate)
VALUES 
('Alice', 'Johnson', 'Software Engineer', 75000.00, '2022-01-15'),
('Bob', 'Smith', 'Project Manager', 85000.00, '2021-06-23');
GO

-- Step 5: Query the Table to Verify Data (Optional)
-- Example: Select all employees
SELECT * FROM Employees;
GO
