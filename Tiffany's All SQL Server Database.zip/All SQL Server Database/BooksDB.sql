-- Step 1: Create the BooksDB Database
CREATE DATABASE BooksDB;
GO

-- Step 2: Use the BooksDB Database
USE BooksDB;
GO

-- Step 3: Create the Books Table
CREATE TABLE Books (
    BookID INT PRIMARY KEY IDENTITY(1,1),
    Title NVARCHAR(100) NOT NULL,
    Author NVARCHAR(100) NOT NULL,
    Genre NVARCHAR(50),
    PublishedDate DATE
);
GO

-- Step 4: Insert Sample Data (Optional)
-- Example: Inserting sample book data
INSERT INTO Books (Title, Author, Genre, PublishedDate)
VALUES 
('To Kill a Mockingbird', 'Harper Lee', 'Fiction', '1960-07-11'),
('1984', 'George Orwell', 'Dystopian', '1949-06-08');
GO

-- Step 5: Query the Table to Verify Data (Optional)
-- Example: Select all books
SELECT * FROM Books;
GO

